# journey-27 计划：去掉文案 + 终章“来到大家身边”3D 场景

(draft — waiting for copy inventory)
