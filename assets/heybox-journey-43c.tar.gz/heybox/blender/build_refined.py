import bpy,json,os,math,random
from mathutils import Matrix,Vector
OUT=os.path.dirname(os.path.abspath(__file__))
d=json.load(open(OUT+'/original_assembly.json'))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
model=bpy.data.collections.new('HEYBOX | preserved original assembly');scene.collection.children.link(model)
studio=bpy.data.collections.new('STUDIO | excluded from export');scene.collection.children.link(studio)
def mat(name,c,metal,rough,em=None,strength=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if em:p.inputs['Emission Color'].default_value=(*em,1);p.inputs['Emission Strength'].default_value=strength
 return m
orig={k:mat('ORIGINAL | '+k[:8],v['color'],v['metalness'],v['roughness'],v['emissive'],v['emissiveIntensity']) for k,v in d['materials'].items()}
face=mat('REFINED | fine matte black face',(.018,.020,.024),.62,.47)
edge=mat('REFINED | controlled gunmetal bevel',(.105,.124,.143),.88,.36)
body=mat('REFINED | machined dark titanium depth',(.095,.112,.13),.85,.40)
rear=mat('REFINED | recessed black rear',(.009,.012,.016),.66,.49)
seam=mat('REFINED | precise restrained parting seam',(.052,.065,.078),.72,.48)
ice=mat('REFINED | restrained ice-blue light guide',(.28,.43,.50),.38,.33,(.30,.56,.72),.28)
ivory=mat('REFINED | soft aperture light',(.49,.65,.69),.25,.36,(.46,.70,.80),.32)
random.seed(210);N=256;height=[[random.random() for x in range(N)] for y in range(N)];pixels=[]
for y in range(N):
 for x in range(N):
  v=Vector(((height[y][(x-1)%N]-height[y][(x+1)%N])*.105,(height[(y-1)%N][x]-height[(y+1)%N][x])*.105,1)).normalized();pixels.extend((v.x*.5+.5,v.y*.5+.5,v.z*.5+.5,1))
img=bpy.data.images.new('Fine matte micrograin | packed tangent normal',width=N,height=N,alpha=False);img.colorspace_settings.name='Non-Color';img.pixels=pixels;img.filepath_raw=OUT+'/fine_matte_normal.png';img.file_format='PNG';img.save();img.pack()
for m,strength in [(face,.19),(rear,.10),(body,.055)]:
 ns=m.node_tree.nodes;ls=m.node_tree.links;t=ns.new('ShaderNodeTexImage');t.image=img;t.location=(-450,-150);n=ns.new('ShaderNodeNormalMap');n.inputs['Strength'].default_value=strength;n.location=(-220,-120);ls.new(t.outputs['Color'],n.inputs['Color']);ls.new(n.outputs['Normal'],ns.get('Principled BSDF').inputs['Normal'])
objects={};original_slots={};refined_slots={};original_normals={};refined_normals={};audit=[]
def matrix(arr):return Matrix([arr[i:i+4] for i in range(0,16,4)]).transposed()
for index,v in enumerate(d['objects']):
 name=v['name'] or 'local orientation'
 if v['type']=='GROUP':o=bpy.data.objects.new(name,None);o.empty_display_size=.12
 else:
  g=d['geometries'][v['geo']];p=g['position'];verts=[p[i:i+3] for i in range(0,len(p),3)]
  if v['type']=='LINE':
   curve=bpy.data.curves.new(name,'CURVE');curve.dimensions='3D';curve.resolution_u=1;curve.bevel_depth=.0022;curve.bevel_resolution=2;s=curve.splines.new('POLY');s.points.add(len(verts)-1)
   for point,co in zip(s.points,verts):point.co=(*co,1)
   s.use_cyclic_u=True;o=bpy.data.objects.new(name,curve)
  else:
   ids=g['index'] if g['index'] else list(range(len(verts)));faces=[ids[i:i+3] for i in range(0,len(ids),3)];me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me)
   uv=me.uv_layers.new(name='Fine grain UV')
   for poly in me.polygons:
    for li in poly.loop_indices:
     vi=me.loops[li].vertex_index;co=me.vertices[vi].co;uv.data[li].uv=(co.x*9+co.z*3,co.y*9+co.z*3)
    for group in g['groups']:
     if group['start']<=poly.index*3<group['start']+group['count']:poly.material_index=group['materialIndex']
    poly.use_smooth=True
   if g['normal']:
    ns=g['normal'];raw=[Vector(ns[i:i+3]) for i in range(0,len(ns),3)]
    buckets={}
    for vi,co in enumerate(verts):
     key=tuple(round(c,6) for c in co);nk=tuple(round(c,6) for c in raw[vi]);buckets.setdefault(key,{})[nk]=raw[vi]
    original_normals[o.name]=[raw[loop.vertex_index][:] for loop in me.loops]
    smooth=[]
    for poly in me.polygons:
     for li in poly.loop_indices:
      vi=me.loops[li].vertex_index;n=raw[vi]
      if poly.material_index>0:
       candidates=[q for q in buckets[tuple(round(c,6) for c in verts[vi])].values() if q.dot(n)>.5]
       n=sum(candidates,Vector((0,0,0))).normalized()
      smooth.append(n[:])
    refined_normals[o.name]=smooth;me.normals_split_custom_set(smooth)
   audit.append({'name':name,'source_vertices':len(verts),'source_triangles':len(faces),'source_geometry_id':v['geo'],'geometry_changed':False,'refined_bevel_normals':'Coincident bevel normals averaged within 60 degrees; flat cap normals retained'})
  original_slots[o.name]=[orig[k] for k in v['materials']]
  if name=='bevelled-graphite-face':rm=[face,edge]
  elif name=='machined-shell-depth':rm=[body,body]
  elif name=='recessed-rear-cover':rm=[rear,body]
  elif name in ['silver-face-gasket','brushed-aperture-lip']:rm=[edge,edge]
  elif name=='circumferential-shell-seam':rm=[seam]
  elif name in ['recessed-inner-light-guide','deep-iceblue-light']:rm=[ice,ice][:len(v['materials'])]
  elif name=='ivory-aperture-light':rm=[ivory,ivory]
  elif name=='hollow-load-bearing-rim':rm=[rear,body]
  else:rm=[body,rear]
  refined_slots[o.name]=rm
  for m in rm:o.data.materials.append(m)
 model.objects.link(o);objects[v['id']]=o;o['Original component']=name;o['Source']='Exact original heybox-core.js mesh and local transform'
 if v.get('parent') in objects:o.parent=objects[v['parent']]
 o.matrix_local=matrix(v['matrix'])
# Each source material slot and custom vertex normal is retained. No remeshing or silhouette approximation.
def appearance(refined=True):
 slots=refined_slots if refined else original_slots
 for o in model.objects:
  if o.name in slots:
   for i,m in enumerate(slots[o.name]):o.data.materials[i]=m
   normals=refined_normals if refined else original_normals
   if o.name in normals:o.data.normals_split_custom_set(normals[o.name])
def pose(value):
 for k,v in d['states'][str(value)].items():
  if k in objects:objects[k].matrix_local=matrix(v['matrix'])
 portal=next(o for o in model.objects if o.name=='hollow-hexagonal-throat')
 for o in portal.children_recursive:o.hide_render=(value==0)
world=bpy.data.worlds.new('Neutral dark studio');scene.world=world;world.use_nodes=True;world.node_tree.nodes.get('Background').inputs[0].default_value=(.075,.085,.105,1);world.node_tree.nodes.get('Background').inputs[1].default_value=.32
# Seamless blue-black backdrop; no image compositing or generated product mockup.
backmat=mat('STUDIO | backdrop',(.012,.017,.026),0,.8)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-5));bg=bpy.context.object;bg.name='Studio backdrop';bg.data.materials.append(backmat)
for c in list(bg.users_collection):c.objects.unlink(bg)
studio.objects.link(bg)
def area(name,pos,energy,size,col=(1,1,1),target=(0,0,0),sy=None):
 ld=bpy.data.lights.new(name,'AREA');ld.energy=energy;ld.shape='RECTANGLE';ld.size=size;ld.size_y=sy or size;ld.color=col;o=bpy.data.objects.new(name,ld);studio.objects.link(o);o.location=pos;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
area('Key large softbox',(-3.7,4.8,5.0),650,4.8,(.95,.97,1))
area('Front subtle fill',(3.2,-.5,5.5),170,4,(1,.98,.95))
area('Long rim softbox',(3.8,1.5,-1.8),380,2.8,(.79,.88,1),sy=5)
area('Upper edge softbox',(-1,5,-.5),280,3,(1,1,1),sy=2)
def camera(name,pos,scale,target=(0,0,0)):
 c=bpy.data.cameras.new(name);c.type='ORTHO';c.ortho_scale=scale;o=bpy.data.objects.new(name,c);studio.objects.link(o);o.location=pos;direction=(Vector(target)-o.location).normalized();right=direction.cross(Vector((0,1,0))).normalized();up=right.cross(direction);o.rotation_euler=Matrix((right,up,-direction)).transposed().to_euler();return o
hero=camera('Hero | original and refined exact comparison',(4.3,1.7,9),4.8)
front=camera('Front | preserved silhouette',(0,0,10),4.7)
opened=camera('Slightly opened | original interior',(3.6,1.7,9),6.1)
detail=camera('Detail | original layered edge',(5.5,1.1,8),2.6,(.80,.35,-.10))
scene.render.engine='CYCLES';scene.cycles.samples=160;scene.cycles.use_denoising=False;scene.render.resolution_x=1100;scene.render.resolution_y=1100;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.25
scene['Design scope']='Original silhouette, 15 source meshes, 4 seams, exact bevels, thickness, local transforms and split hierarchy retained. Surface finish and existing bevel shading refined. Original additive 2D glow sprite intentionally omitted from portable geometry.'
scene['Original mesh count']=15
scene.camera=hero;pose(0);appearance(True)
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/heybox_original_refined.blend')
bpy.ops.object.select_all(action='DESELECT')
for o in model.objects:o.select_set(True)
bpy.context.view_layer.objects.active=next(o for o in model.objects if o.type=='MESH')
portal=next(o for o in model.objects if o.name=='hollow-hexagonal-throat')
portal['Closed visibility']='Scale zero in GLB only; set scale to 0.6 to restore original closed rest transform, or animate using source states.'
portal['Original closed scale']=0.6
portal.scale=(0,0,0)
bpy.ops.export_scene.gltf(filepath=OUT+'/heybox_original_refined.glb',export_format='GLB',use_selection=True,export_apply=True,export_yup=False,export_animations=False,export_extras=True)
pose(0)
json.dump({'source':'original_heybox_core.js','preserved_source_meshes':len(audit),'seam_paths':4,'geometry':audit,'refinement':'Matte black face, controlled gunmetal trims, reduced light emission, packed micro-normal texture and angle-limited bevel-normal smoothing. All vertex coordinates, topology and transforms preserved.','sprite_note':'Original screen-space glow omitted; physical light guides and five original aperture rings retained.','normal_texture_packed':img.packed_file is not None},open(OUT+'/validation.json','w'),indent=2)
for fn,cam,state,refine in [('01_original_hero.png',hero,0,False),('02_refined_hero.png',hero,0,True),('03_refined_front.png',front,0,True),('04_original_opened.png',opened,.32,False),('05_refined_opened.png',opened,.32,True),('06_refined_layer_detail.png',detail,0,True)]:
 appearance(refine);pose(state);scene.camera=cam;scene.render.filepath=OUT+'/'+fn;bpy.ops.render.render(write_still=True)
appearance(True);pose(0);scene.camera=hero;bpy.ops.wm.save_as_mainfile(filepath=OUT+'/heybox_original_refined.blend')
exec(compile(open(OUT+'/finalize_blend.py').read(),OUT+'/finalize_blend.py','exec'))
print('REFINED ORIGINAL BUILD COMPLETE')
