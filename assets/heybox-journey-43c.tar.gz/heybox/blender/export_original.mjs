import fs from 'node:fs';
import * as THREE from '../dist/vendor/three.module.js';
import {createHeyboxCore} from './original_heybox_core.js';
const api=createHeyboxCore({THREE});const geos={},mats={},objects=[];
api.group.traverse(o=>{if(o.isSprite)return;const obj={id:o.uuid,parent:o.parent?.uuid,name:o.name,type:o.isMesh?'MESH':o.isLineLoop?'LINE':'GROUP',matrix:o.matrix.toArray()};o.updateMatrix();obj.matrix=o.matrix.toArray();
if(o.geometry){const g=o.geometry,p=g.attributes.position;obj.geo=g.uuid;if(!geos[g.uuid])geos[g.uuid]={position:Array.from(p.array),normal:g.attributes.normal?Array.from(g.attributes.normal.array):null,uv:g.attributes.uv?Array.from(g.attributes.uv.array):null,index:g.index?Array.from(g.index.array):null,groups:g.groups};obj.materials=[].concat(o.material).map(m=>{mats[m.uuid]={color:m.color.toArray(),metalness:m.metalness??0,roughness:m.roughness??.5,emissive:m.emissive?.toArray()??[0,0,0],emissiveIntensity:m.emissiveIntensity??0};return m.uuid;});}objects.push(obj);});
const states={};for(const p of [0,.32,.65,1]){api.update(p,0,{reduced:true});api.group.updateMatrixWorld(true);states[p]={};api.group.traverse(o=>{o.updateMatrix();states[p][o.uuid]={matrix:o.matrix.toArray(),visible:o.visible};});}
fs.writeFileSync(new URL('./original_assembly.json',import.meta.url),JSON.stringify({source:'./original_heybox_core.js',geometries:geos,materials:mats,objects,states},null,0));console.log(objects.map(o=>o.type+' '+o.name).join('\n'));
