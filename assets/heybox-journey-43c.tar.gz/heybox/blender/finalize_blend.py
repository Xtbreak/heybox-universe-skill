import bpy,json,os
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=OUT+'/heybox_original_refined.blend')
d=json.load(open(OUT+'/original_assembly.json'));model=bpy.data.collections['HEYBOX | preserved original assembly']
for src,o in zip(d['objects'],list(model.objects)):
 assert o.get('Original component')==(src['name'] or 'local orientation')
 o['Source UUID']=src['id']
text=bpy.data.texts.new('Original poses.json');text.write(json.dumps(d['states']))
helper=bpy.data.texts.new('Apply original pose.py');helper.write('''# Set OPEN to 0, 0.32, 0.65, or 1; run in Blender Text Editor.\nimport bpy, json\nfrom mathutils import Matrix\nOPEN = 0.32\nstates=json.loads(bpy.data.texts['Original poses.json'].as_string())\nfor o in bpy.data.collections['HEYBOX | preserved original assembly'].objects:\n    k=o.get('Source UUID')\n    if k in states[str(OPEN)]:\n        arr=states[str(OPEN)][k]['matrix']\n        o.matrix_local=Matrix([arr[i:i+4] for i in range(0,16,4)]).transposed()\nfor o in bpy.data.objects['hollow-hexagonal-throat'].children_recursive:\n    o.hide_render=(OPEN==0)\n    o.hide_set(OPEN==0)\n''')
for o in bpy.data.objects['hollow-hexagonal-throat'].children_recursive:o.hide_set(True)
bpy.context.scene['Opening helper']='Text Editor > Apply original pose.py: choose 0, 0.32, 0.65 or 1 and run.'
bpy.context.scene['Design scope']='Original silhouette, 15 source meshes, four seams, exact bevel geometry, thickness and local transforms preserved. Surface finish and existing bevel shading refined; planar cap normals retained.'
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/heybox_original_refined.blend')
print('FINAL BLEND includes original pose helper and correct viewport visibility')
