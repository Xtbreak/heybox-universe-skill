import bpy,os
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=OUT+'/heybox_original_refined.blend')
model=bpy.data.collections['HEYBOX | preserved original assembly']
portal=bpy.data.objects['hollow-hexagonal-throat'];portal['Closed visibility']='Scale zero in GLB only; use original source pose transforms to open.';portal['Original closed scale']=0.6;portal.scale=(0,0,0)
bpy.ops.object.select_all(action='DESELECT')
for o in model.objects:o.select_set(True)
bpy.context.view_layer.objects.active=next(o for o in model.objects if o.type=='MESH')
bpy.ops.export_scene.gltf(filepath=OUT+'/heybox_original_refined.glb',export_format='GLB',use_selection=True,export_apply=True,export_yup=False,export_animations=False,export_extras=True)
print('FINAL CLOSED GLB EXPORTED IN ORIGINAL THREE.JS AXES')
