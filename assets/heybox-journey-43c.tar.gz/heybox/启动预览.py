#!/usr/bin/env python3
"""Local-only static preview. Does not install dependencies or open a browser."""
from pathlib import Path
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import argparse
parser=argparse.ArgumentParser(description="小黑盒本地预览")
parser.add_argument("--port",type=int,default=8000)
args=parser.parse_args()
root=Path(__file__).resolve().parent/"dist"
handler=partial(SimpleHTTPRequestHandler,directory=str(root))
class PreviewServer(ThreadingHTTPServer):
    # Module preloads and GLB fetches arrive together in Chromium browsers.
    request_queue_size=128
    daemon_threads=True
try:
    server=PreviewServer(("127.0.0.1",args.port),handler)
except OSError as exc:
    raise SystemExit(f"启动失败：{exc}。如端口占用，使用 --port 8001。")
print(f"本地预览：http://127.0.0.1:{args.port}/sample.html?rev=journey-25",flush=True)
print("按 Ctrl+C 停止。仅绑定本机，不对局域网公开。",flush=True)
try:
    server.serve_forever()
except KeyboardInterrupt:
    print("\n已停止。")
finally:
    server.server_close()
